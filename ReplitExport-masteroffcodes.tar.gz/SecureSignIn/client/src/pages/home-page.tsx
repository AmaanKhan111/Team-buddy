import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-4 p-8">
        <h1 className="text-4xl font-bold">Welcome, {user?.username}!</h1>
        <p className="text-muted-foreground">You have successfully authenticated.</p>
        <Button 
          onClick={() => logoutMutation.mutate()} 
          disabled={logoutMutation.isPending}
        >
          {logoutMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Logout
        </Button>
      </div>
    </div>
  );
}
