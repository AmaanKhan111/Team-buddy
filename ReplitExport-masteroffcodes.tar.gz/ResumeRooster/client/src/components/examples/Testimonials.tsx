import Testimonials from '../Testimonials';

export default function TestimonialsExample() {
  return <Testimonials />;
}
